<?php
session_start();
if(!isset($_SESSION['id'])) {
    session_abort();
    header('Location: loginregister.php');
}

class deleteStatus {
    public static function deleteReq() {
        $conn = new mysqli('localhost:3306','guest','Nl5m8hCVkrE)nx/G','mechanix');
        $conn -> begin_transaction();
        try{
            $id = $_POST['id'];
            $sql = "DELETE FROM terminy WHERE `terminy`.`id` = '$id'";
            $conn ->query($sql);
            $conn -> commit(); 
            header("Location: panelStatus.php");
        } catch(Exception $e) {
            $conn->rollBack();
            header("Location: panelStatus.php");
        }
    }
}

$delete = new deleteStatus();
$delete -> deleteReq();
session_commit();
// ?>