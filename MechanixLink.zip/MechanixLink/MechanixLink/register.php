<?php 
final class registerClient {
    private $login, $password, $imie, $nazwisko,$email,$telefon;
public function register() {
    $conn = new mysqli('localhost:3306','guest','Nl5m8hCVkrE)nx/G','mechanix');

    if($_SERVER['REQUEST_METHOD'] === 'POST') {
        $login = $_POST['login'];
        $password = $_POST['password'];
        $imie = $_POST['imie'];
        $nazwisko = $_POST['nazwisko'];
        $email = $_POST['email'];
        $telefon = $_POST['telefon'];

        // Zabezpieczenie przed SQL injection
        $login = mysqli_real_escape_string($conn, $login);
        $password = mysqli_real_escape_string($conn, $password);
        $imie = mysqli_real_escape_string($conn, $imie);
        $nazwisko = mysqli_real_escape_string($conn, $nazwisko);
        $email = mysqli_real_escape_string($conn, $email);
        $telefon = mysqli_real_escape_string($conn, $telefon);

        $conn -> begin_transaction();
        try {
        $sql = "SELECT * FROM uzytkownicy WHERE login = $login";
        $result = $conn->query($sql);
        if($result -> num_rows == 0) { 
            $sql = "INSERT INTO `uzytkownicy` (`id_uzytkownika`, `login`, `haslo`, `typ`) VALUES (null, '$login', '$password', 'klient')";
            $conn->query($sql);
    
    
            $result = $conn->query("SELECT * FROM uzytkownicy WHERE login = '$login' AND haslo = '$password'");
            $row = $result -> fetch_row();
    
            $sql = "INSERT INTO klienci (id_klienta, imie, nazwisko, telefon, email) VALUES ('$row[0]','$imie','$nazwisko','$telefon','$email')";
            $conn->query($sql);
            if(isset($_COOKIE['invalidReg']) && $_COOKIE['invalidReg']) {
                setcookie('invalidReg', false,time() + 1,'/');
            }
            $conn -> commit();
            header('Location: loginregister.php');
        } else throw new Exception('invalidRegster');
        } catch (Exception $e) {
            $conn ->rollback();
            setcookie('invalidReg',true,time() + 1,'/');
            header('Location: loginregister.php');
        }
    }
}
}
$klient = new registerClient();
$klient->register();
?>