-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Sty 06, 2024 at 07:51 PM
-- Wersja serwera: 10.4.32-MariaDB
-- Wersja PHP: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `mechanix`
--

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `klienci`
--

CREATE TABLE `klienci` (
  `id_klienta` int(11) NOT NULL,
  `imie` varchar(255) NOT NULL,
  `nazwisko` varchar(255) NOT NULL,
  `telefon` int(9) NOT NULL,
  `email` varchar(40) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `klienci`
--

INSERT INTO `klienci` (`id_klienta`, `imie`, `nazwisko`, `telefon`, `email`) VALUES
(2, 'Marek', 'Komucha', 123123123, 'ASDAS@SADAS.COM'),
(7, 'Marek', 'Woda', 123123123, 'maro12@gmail.com'),
(8, 'Marcin', 'Kolasinski', 321321321, 'mar11@gmail.com'),
(9, 'test', 'test', 123123123, 'test11@gmail.com'),
(10, 'tetowy ', 'testow', 123321899, 'test@test.test'),
(11, 'Marcin', 'Marcin', 798319520, '264155@student.pwr.edu.pl');

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `pracownicy`
--

CREATE TABLE `pracownicy` (
  `id_pracownika` int(11) NOT NULL,
  `specjalizacja` varchar(30) NOT NULL,
  `id_warsztatu` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `samochody`
--

CREATE TABLE `samochody` (
  `id` int(11) NOT NULL,
  `marka` varchar(255) NOT NULL,
  `model` varchar(255) NOT NULL,
  `pojemnosc_silnika` float NOT NULL,
  `rodzaj_paliwa` varchar(20) NOT NULL,
  `numer_vin` varchar(17) NOT NULL,
  `wlasciciel` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `samochody`
--

INSERT INTO `samochody` (`id`, `marka`, `model`, `pojemnosc_silnika`, `rodzaj_paliwa`, `numer_vin`, `wlasciciel`) VALUES
(6, 'Audi', 'A6', 1.9, 'Diesel', '12312312312312312', 7),
(7, 'Volkswagen', 'Golf', 1.9, 'Diesel', '12312312312312312', 8),
(8, 'Skoda', 'Octavia', 1.9, 'Diesel', '12322222312312312', 9),
(9, 'Audi', 'A4', 1.9, 'Diesel', '412521ga612lty521', 7),
(14, 'BMW', 'E39', 2.2, 'Benzyna', 'chujciwdupe692173', 7),
(15, 'Jeep', 'testowy', 2.1, 'Benzyna', '33333333333333333', 2),
(16, 'Audi', 'E39', 12, 'Diesel', '00000000000000000', 7);

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `terminy`
--

CREATE TABLE `terminy` (
  `id` int(11) NOT NULL,
  `id_warsztatu` int(11) NOT NULL,
  `id_uslugi` int(11) NOT NULL,
  `id_samochodu` int(11) DEFAULT NULL,
  `status_zlecenia` enum('przyjety','w trakcie naprawy','zakonczony') NOT NULL,
  `data_przyjecia` datetime NOT NULL DEFAULT current_timestamp(),
  `data_oddania` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `terminy`
--

INSERT INTO `terminy` (`id`, `id_warsztatu`, `id_uslugi`, `id_samochodu`, `status_zlecenia`, `data_przyjecia`, `data_oddania`) VALUES
(2, 3, 2, 6, 'zakonczony', '2023-12-28 20:44:59', '2023-12-29 13:13:14'),
(3, 2, 5, 6, 'przyjety', '2023-12-28 20:49:26', '0000-00-00 00:00:00'),
(4, 2, 6, 8, 'przyjety', '2023-12-28 20:51:30', '0000-00-00 00:00:00'),
(5, 2, 1, 9, 'przyjety', '2023-12-30 12:43:40', '0000-00-00 00:00:00'),
(6, 1, 1, 7, 'przyjety', '2024-01-03 20:17:41', '0000-00-00 00:00:00'),
(8, 1, 2, 8, 'przyjety', '2024-01-03 20:30:58', '0000-00-00 00:00:00'),
(9, 2, 3, 14, 'przyjety', '2024-01-04 20:18:08', '0000-00-00 00:00:00'),
(10, 1, 8, 15, 'przyjety', '2024-01-06 19:28:15', '0000-00-00 00:00:00'),
(11, 2, 10, 16, 'przyjety', '2024-01-06 19:38:55', '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `uslugi`
--

CREATE TABLE `uslugi` (
  `id` int(11) NOT NULL,
  `rodzaj_uslugi` varchar(50) NOT NULL,
  `cena` int(10) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `uslugi`
--

INSERT INTO `uslugi` (`id`, `rodzaj_uslugi`, `cena`) VALUES
(1, 'Serwis olejowy', 100),
(2, 'Diagnostyka komputerowa silnika', 70),
(3, 'Naprawy silnika', 400),
(4, 'Naprawy układu hamulcowego', 200),
(5, 'Naprawy układu zawieszenia', 250),
(6, 'Naprawy układu wydechowego', 50),
(7, 'Diagnostyka i naprawa systemów elektrycznych', 250),
(8, 'Naprawa skrzyni biegów', 500),
(9, 'Naprawa klimatyzacji', 50),
(10, 'Wymiana opon i wyważanie kół', 80),
(11, 'Naprawy układu chodzenia', 200),
(12, 'Naprawy układu paliwowego', 150);

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `uzytkownicy`
--

CREATE TABLE `uzytkownicy` (
  `id_uzytkownika` int(11) NOT NULL,
  `login` char(20) NOT NULL,
  `haslo` char(20) NOT NULL,
  `typ` enum('klient','pracownik') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `uzytkownicy`
--

INSERT INTO `uzytkownicy` (`id_uzytkownika`, `login`, `haslo`, `typ`) VALUES
(1, 'admin', 'admin', 'pracownik'),
(2, 'marek11', 'haslo11', 'klient'),
(7, 'maro12', 'maro12', 'klient'),
(8, 'mar11', 'mar11', 'klient'),
(9, 'test11', 'test11', 'klient'),
(10, 'test1', 'test1', 'klient'),
(11, 'marcin123', 'marcinhaslo', 'klient');

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `warsztaty`
--

CREATE TABLE `warsztaty` (
  `id` int(11) NOT NULL,
  `adres` varchar(255) NOT NULL,
  `miasto` varchar(255) NOT NULL,
  `kod_pocztowy` varchar(6) NOT NULL,
  `telefon` int(9) NOT NULL,
  `specjalizacja` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `warsztaty`
--

INSERT INTO `warsztaty` (`id`, `adres`, `miasto`, `kod_pocztowy`, `telefon`, `specjalizacja`) VALUES
(1, 'Krzyki', 'Krzyki', '12-123', 111111111, 'samochody'),
(2, 'śródmieście', 'śródmieście', '12-123', 222222222, 'auta'),
(3, 'Fabryczna', 'Fabryczna', '12-123', 333333333, 'bmw');

--
-- Indeksy dla zrzutów tabel
--

--
-- Indeksy dla tabeli `klienci`
--
ALTER TABLE `klienci`
  ADD PRIMARY KEY (`id_klienta`);

--
-- Indeksy dla tabeli `pracownicy`
--
ALTER TABLE `pracownicy`
  ADD PRIMARY KEY (`id_pracownika`),
  ADD KEY `Relationship6` (`id_warsztatu`);

--
-- Indeksy dla tabeli `samochody`
--
ALTER TABLE `samochody`
  ADD PRIMARY KEY (`id`),
  ADD KEY `Relationship1` (`wlasciciel`);

--
-- Indeksy dla tabeli `terminy`
--
ALTER TABLE `terminy`
  ADD PRIMARY KEY (`id`),
  ADD KEY `IX_Relationship4` (`id_warsztatu`),
  ADD KEY `IX_Relationship13` (`id_samochodu`);

--
-- Indeksy dla tabeli `uslugi`
--
ALTER TABLE `uslugi`
  ADD PRIMARY KEY (`id`);

--
-- Indeksy dla tabeli `uzytkownicy`
--
ALTER TABLE `uzytkownicy`
  ADD PRIMARY KEY (`id_uzytkownika`);

--
-- Indeksy dla tabeli `warsztaty`
--
ALTER TABLE `warsztaty`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `telefon` (`telefon`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `klienci`
--
ALTER TABLE `klienci`
  MODIFY `id_klienta` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `pracownicy`
--
ALTER TABLE `pracownicy`
  MODIFY `id_pracownika` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `samochody`
--
ALTER TABLE `samochody`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `terminy`
--
ALTER TABLE `terminy`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `uslugi`
--
ALTER TABLE `uslugi`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `uzytkownicy`
--
ALTER TABLE `uzytkownicy`
  MODIFY `id_uzytkownika` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `warsztaty`
--
ALTER TABLE `warsztaty`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `klienci`
--
ALTER TABLE `klienci`
  ADD CONSTRAINT `Relationship20` FOREIGN KEY (`id_klienta`) REFERENCES `uzytkownicy` (`id_uzytkownika`);

--
-- Constraints for table `pracownicy`
--
ALTER TABLE `pracownicy`
  ADD CONSTRAINT `Relationship22` FOREIGN KEY (`id_pracownika`) REFERENCES `uzytkownicy` (`id_uzytkownika`),
  ADD CONSTRAINT `Relationship6` FOREIGN KEY (`id_warsztatu`) REFERENCES `warsztaty` (`id`);

--
-- Constraints for table `samochody`
--
ALTER TABLE `samochody`
  ADD CONSTRAINT `Relationship1` FOREIGN KEY (`wlasciciel`) REFERENCES `klienci` (`id_klienta`) ON UPDATE CASCADE;

--
-- Constraints for table `terminy`
--
ALTER TABLE `terminy`
  ADD CONSTRAINT `Relationship13` FOREIGN KEY (`id_samochodu`) REFERENCES `samochody` (`id`),
  ADD CONSTRAINT `Relationship4` FOREIGN KEY (`id_warsztatu`) REFERENCES `warsztaty` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
