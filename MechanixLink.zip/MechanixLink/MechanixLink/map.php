<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Mapa - MechanixLink</title>
    <link rel="stylesheet" href="stylepanel.css">
</head>
<body>
    <header>
        <h2 class="logo">MechanixLink</h2>
        <nav class="navigation">
            <a href="panel.php">Panel Klienta</a>
            <a href="current-info.php">Aktualne Informacje</a>
            <a href="map.php">Mapa z Dojazdem</a>
            <a href="contact1.php">Kontakt</a>
            <a href = "logout.php">Wyloguj</a>
        </nav>
    </header>

    <section class="map-section">
        <div class="map-container">
            <h1>To jaki warsztat wybierzesz dziś?</h1>
            <p>
                Przedstawiamy przed Tobą adresy i lokalizacje naszych warsztatów we Wrocławiu.
            </p>
            <br>
            <h2>Warsztat - Fabryczna</h2>
            <p>
                <strong>Adres:</strong>
                Wrocław: ul. Nowodworska 53A, 54-443, tel. 111-222-333
            </p>
            <strong>Lokalizacja:</strong>
            <div class="localization1">
                <p>

                </p>
            </div>
            <br>

            <h2>Warsztat - Śródmieście</h2>
            <p>
                <strong>Adres:</strong>
                Wrocław: ul. Wybrzeże Stanisława Wyspiańskiego 27, 50-370, tel. 090-808-070
            </p>
            <strong>Lokalizacja:</strong>
            <div class="localization2">
                <p>

                </p>
            </div>
            <br>

            <h2>Warsztat - Krzyki</h2>
            <p>
                <strong>Adres:</strong>
                Wrocław: ul. Złotostocka 14cz, 50-510, tel. 777-555-000
            </p>
            <strong>Lokalizacja:</strong>
            <div class="localization3">
                <p>

                </p>
            </div>
            <br>
        </div>
    </section>

    <script src="panel.js"></script>
    <script type="module" src="https://unpkg.com/ionicons@7.1.0/dist/ionicons/ionicons.esm.js"></script>
    <script nomodule src="https://unpkg.com/ionicons@7.1.0/dist/ionicons/ionicons.js"></script>

</body>
</html>