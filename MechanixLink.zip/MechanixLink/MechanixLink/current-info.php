<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Aktualne informacje - MechanixLink</title>
    <link rel="stylesheet" href="stylepanel.css">
</head>
<body>
    <header>
        <h2 class="logo">MechanixLink</h2>
        <nav class="navigation">
            <a href="panel.php">Panel Klienta</a>
            <a href="current-info.php">Aktualne Informacje</a>
            <a href="map.php">Mapa z Dojazdem</a>
            <a href="contact1.php">Kontakt</a>
            <a href = "logout.php">Wyloguj</a>
        </nav>
    </header>

    <section class="about-section">
        <div class="blurred-background">
            <div class="content-container">
                <h1>Aktualne Informacje</h1>
                <p>
                    Jesteśmy przekonani, że zadowolenie klienta jest kluczem do sukcesu. Dlatego też stawiamy na indywidualne podejście do każdego klienta, służąc pomocą, doradzając i informując na każdym etapie naprawy.
                    Dziękujemy za zaufanie, jakim nas obdarzają nasi klienci. Jesteśmy gotowi sprostać wszelkim wyzwaniom związanym z Twoim pojazdem i zapewnić mu najwyższą jakość opieki.

                    Nasza pasja do doskonałości oraz zaufanie naszych klientów uczyniły nas liderem branży.
                </p>
                <br>
                <h2>Godziny otwarcia warsztatów:</h2>
                <p>
                    <br>
                    Warsztat - Farbryczna: <strong>8:00 - 18:00</strong>
                    <br>
                    Warsztat - Śródmieście: <strong>7:30 - 19:30</strong>
                    <br>
                    Warsztat - Krzyki: <strong>8:30 - 18:30</strong>
                </p>
                <br>
                <h2>AKTUALNE PROMOCJE</h2>
                <p>
                    <br>
                    <strong>Atrakcyjne Zniżki:</strong>
                    <br>
                    Oferujemy zniżki na różnorodne usługi naprawcze, aby umożliwić naszym klientom korzystanie z wysokiej jakości usług za konkurencyjne ceny. Przywiązujemy wagę do uczciwego podejścia do cen i zawsze staramy się dostarczyć korzyści finansowe naszym klientom.
                </p>
                <p>
                    <strong>Programy Rabatowe:</strong>
                    <br>
                    Nasze programy rabatowe są zaprojektowane tak, aby nagradzać stałych klientów, którzy wracają do naszego warsztatu. Im częściej korzystasz z naszych usług, tym większe korzyści możesz otrzymać w ramach naszych specjalnych programów.
                </p>
                <p>
                    <strong>Sezonowe Oferty:</strong>
                    <br>
                    Dbamy o to, aby nasze promocje odpowiadały zmieniającym się potrzebom naszych klientów. Oferujemy sezonowe oferty, które obejmują różne aspekty opieki nad pojazdem, od przygotowania do zimy po letnie przeglądy.
                </p>
                <p>
                    <strong>Bonusy dla Lojalnych Klientów:</strong>
                    <br>
                    Nasze programy lojalnościowe obejmują dodatkowe bonusy, takie jak bezpłatne przeglądy, rabaty na przyszłe naprawy czy specjalne prezenty dla naszych najbardziej lojalnych klientów.
                </p>
                <h2>Podziękowanie za Zaufanie:</h2>
                <p>
                    Aktualne promocje i programy rabatowe to nasza forma podziękowania za zaufanie, jakim nas obdarzają nasi klienci. Jesteśmy wdzięczni za każdą okazję, kiedy możemy świadczyć usługi naprawcze dla naszych klientów, i chcemy, aby korzystanie z naszych usług było nie tylko korzystne pod względem jakości, ale także cenowo.
                    
                    Dziękujemy za wybieranie naszego warsztatu, a nasze aktualne promocje są dostępne z myślą o Państwa zadowoleniu i satysfakcji.
                </p>
                
            </div>
        </div>
    </section>

    <script src="loginregister.js"></script>
    <script type="module" src="https://unpkg.com/ionicons@7.1.0/dist/ionicons/ionicons.esm.js"></script>
    <script nomodule src="https://unpkg.com/ionicons@7.1.0/dist/ionicons/ionicons.js"></script>

</body>
</html>