document.addEventListener('DOMContentLoaded', () => {
    const reservationStatusBtn = document.querySelector('#reservationStatusBtn');
    const makeReservationBtn = document.querySelector('#makeReservationBtn');
    const costBtn = document.querySelector('#costBtn');

    if (reservationStatusBtn) {
        reservationStatusBtn.addEventListener('click', () => {
            window.location.href = "panelStatus.php";
        });
    }
    if (makeReservationBtn) {
        makeReservationBtn.addEventListener('click', () => {
            window.location.href = "panel.php";
        });
    }
    if (costBtn) {
        costBtn.addEventListener('click', () => {
            window.location.href = "pricingPanel.php";
        });
    }
});