<?php
session_start();
if(!isset($_SESSION['id'])) {
    session_abort();
    header('Location: loginregister.php');
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Panel Klienta - MechanixLink</title>
    <link rel="stylesheet" href="stylepanel.css">
    <script src="panel.js"></script>
</head>
<body>
    <header>
        <h2 class="logo">Witaj kliencie!</h2>
        <nav class="navigation">
            <a href="panel.php">Panel Klienta</a>
            <a href="current-info.php">Aktualne Informacje</a>
            <a href="map.php">Mapa z Dojazdem</a>
            <a href="contact1.php">Kontakt</a>
            <a href = "logout.php">Wyloguj</a>
        </nav>
    </header>

    <section class="reservatio-section">
        <div class="reservatio-container">
            <h3>Status twojego zlecenia</h3>
            <?php 
            echo '<table>';
            session_commit();
            require_once('statusRequest.php');
            echo '</table>';
            ?>
        </div>
    </section>

    <div class="reservation-status">
        <h3>Zarejestruj zlecenie</h3>
        <ul id="reservationStatus"></ul>
        <button id="makeReservationBtn">Zarejestruj zlecenie</button>
    </div>

    <div class="reservation-costs">
        <section id="cost-estimate">
            <h3>Kosztorys</h3>
            <p id="costEstimate"></p>
            <button id="costBtn">Sprawdź kosztorys</button>
        </section>
    </div>
    <script type="module" src="https://unpkg.com/ionicons@7.1.0/dist/ionicons/ionicons.esm.js"></script>
    <script nomodule src="https://unpkg.com/ionicons@7.1.0/dist/ionicons/ionicons.js"></script>
</body>
</html>
