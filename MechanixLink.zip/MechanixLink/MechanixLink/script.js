const wrapper = document.querySelector('.wrapper');
const loginLink = document.querySelector('#loginBtn');
const registerLink = document.querySelector('.register-link');

document.querySelector('#loginBtn').addEventListener('click', () => {
    window.location = "loginregister.php";
});
