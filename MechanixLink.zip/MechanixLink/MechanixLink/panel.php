<?php
session_start();
if(!isset($_SESSION['id'])) {
    session_abort();
    header('Location: loginregister.php');
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Panel Klienta - MechanixLink</title>
    <link rel="stylesheet" href="stylepanel.css">
    <script src="panel.js"></script>
</head>
<body>
    <header>
        <h2 class="logo">Witaj kliencie!</h2>
        <nav class="navigation">
            <a href="panel.php">Panel Klienta</a>
            <a href="current-info.php">Aktualne Informacje</a>
            <a href="map.php">Mapa z Dojazdem</a>
            <a href="contact1.php">Kontakt</a>
            <a href = "logout.php">Wyloguj</a>
        </nav>
    </header>

    <section class="reservatio-section">
        <div class="reservatio-container">
            <h3>Rejestracja nowego zlecenia</h3>
            <form id="reservationForm" action="zlecenie.php" method="post">
                <label for="carBrand">Marka samochodu:</label>
                <select id="serviceTypeBrand" name="serviceTypeBrand" required>
                    <option value="Audi">Audi</option>
                    <option value="BMW">BMW</option>
                    <option value="Citroen">Citroen</option>
                    <option value="Dacia">Dacia</option>
                    <option value="Fiat">Fiat</option>
                    <option value="Ford">Ford</option>
                    <option value="Hyundai">Hyundai</option>
                    <option value="Kia">Kia</option>
                    <option value="Mercedes">Mercedes</option>
                    <option value="Nissan">Nissan</option>
                    <option value="Opel">Opel</option>
                    <option value="Peugeot">Peugeot</option>
                    <option value="Renault">Renault</option>
                    <option value="Seat">Seat</option>
                    <option value="Skoda">Skoda</option>
                    <option value="Toyota">Toyota</option>
                    <option value="Volkswagen">Volkswagen</option>
                    <option value="Volvo">Volvo</option>
                    <option value="Abarth">Abarth</option>
                    <option value="Alfa Romeo">Alfa Romeo</option>
                    <option value="Alpina">Alpina</option>
                    <option value="Cupra">Cupra</option>
                    <option value="Dodge">Dodge</option>
                    <option value="DS">DS</option>
                    <option value="Honda">Honda</option>
                    <option value="Jaguar">Jaguar</option>
                    <option value="Jeep">Jeep</option>
                    <option value="Land Rover">Land Rover</option>
                    <option value="Lexus">Lexus</option>
                    <option value="Maserati">Maserati</option>
                    <option value="Mazda">Mazda</option>
                    <option value="Mini">Mini</option>
                    <option value="Mitsubishi">Mitsubishi</option>
                    <option value="Subaru">Subaru</option>
                    <option value="Suzuki">Suzuki</option>
                    <option value="popularBrand38">Jeżeli nie widzisz marki swojego pojazdu, zadzwoń do nas!</option>
                </select>

                <label for="carModel">Model auta:</label>
                <input type="text" id="carModel" name="carModel" required>

                <label for="engineType">Rodzaj silnika:</label>
                <input type="text" id="engineType" name="engineType" required>

                <label for="serviceType">Paliwo:</label>
                <select id="serviceType" name="fuelType" required>
                <option value="Diesel">Diesel</option>
                <option value="Benzyna">Benzyna</option>
                </select>
                <label for="vinNumber">Numer VIN:</label>
                <input type="text" id="vinNumber" name="vinNumber" maxlength="17" required>

                <label for="serviceType">Wybór usługi:</label>
                <select id="serviceType" name="serviceType" required>
                    <option value="1" data-number="1">Serwis olejowy</option>
                    <option value="2" data-number="2">Diagnostyka komputerowa silnika</option>
                    <option value="3" data-number="3">Naprawy silnika</option>
                    <option value="4" data-number="4">Naprawy układu hamulcowego</option>
                    <option value="5" data-number="5">Naprawy układu zawieszenia</option>
                    <option value="6" data-number="6">Naprawy układu wydechowego</option>
                    <option value="7" data-number="7">Diagnostyka i naprawa systemów elektrycznych</option>
                    <option value="8" data-number="8">Naprawy skrzyni biegów</option>
                    <option value="9" data-number="9">Naprawy klimatyzacji</option>
                    <option value="10" data-number="10">Wymiana opon i wyważanie kół</option>
                    <option value="11" data-number="11">Naprawy układu chłodzenia</option>
                    <option value="12" data-number="12">Naprawy układu paliwowego</option>
                    <option value="13" data-number="13">Ogólna diagnostyka</option>
                </select>
                <label for="workshop">Wybór warsztatu:</label>
                <select id="selectWorkshop" name="selectWorkshop" required>
                    <option value="3">Warsztat - Fabryczna</option>
                    <option value="2">Warsztat - Śródmieście</option>
                    <option value="1">Warsztat - Krzyki</option>
                </select>
                <button type="submit">Zarejestruj zlecenie</button>
            </form>
        </div>
    </section>

    <div class="reservation-status">
        <h3>Status Zlecenia</h3>
        <ul id="reservationStatus"></ul>
        <button id="reservationStatusBtn">Sprawdź status zlecenia</button>
    </div>
    <div class="reservation-costs">
        <section id="cost-estimate">
            <h3>Kosztorys</h3>
            <p id="costEstimate"></p>
            <button id="costBtn">Sprawdź kosztorys</button>
        </section>
    </div>

    <script type="module" src="https://unpkg.com/ionicons@7.1.0/dist/ionicons/ionicons.esm.js"></script>
    <script nomodule src="https://unpkg.com/ionicons@7.1.0/dist/ionicons/ionicons.js"></script>
</body>
</html>
