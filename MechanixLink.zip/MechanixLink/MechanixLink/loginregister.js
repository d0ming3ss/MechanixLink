document.addEventListener('DOMContentLoaded', function () {
    const wrapper = document.querySelector('.wrapper');
    const loginForm = document.querySelector('.form-box.login');
    const registerForm = document.querySelector('.form-box.register');

    document.querySelector('#loginBtn').addEventListener('click', function() {
        window.location = "loginregister.php";
    });

    document.querySelector('.register-link').addEventListener('click', function() {
        wrapper.classList.add('active');
        loginForm.style.transform = 'translateX(-400px)';
        registerForm.style.transform = 'translateX(0)';
        // const reg = document.querySelector('.wrapper.active');
        // reg.addEventListener('HTMLDetailsElement', () => {
        //     reg.style.transform = 'translateX(-200px)';
        // })
    });

    document.querySelector('.login-link').addEventListener('click', function() {
        wrapper.classList.remove('active');
        loginForm.style.transform = 'translateX(0)';
        registerForm.style.transform = 'translateX(400px)';
    });
});