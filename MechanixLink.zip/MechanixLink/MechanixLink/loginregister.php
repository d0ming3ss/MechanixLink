<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Konto - MechanixLink</title>
    <link rel="stylesheet" href="style.css">
    <script src="loginregister.js"></script>
</head>
<body>
    <header>
        <h2 class="logo">MechanixLink</h2>
        <nav class="navigation">
            <a href="home.php">Home</a>
            <a href="about.php">O nas</a>
            <a href="contact.php">Kontakt</a>
            <a href="privacy.php">Polityka prywatności</a>
            <button class="btnLogin-popup" id="loginBtn">Login</button>
        </nav>
    </header>

    <div class="wrapper">
        <div class="form-box login">
            <h2>Login</h2>
            <form action="login.php" method="post">
                <div class="input-box">
                    <span class="icon"><ion-icon name="mail-outline"></ion-icon></span>
                    <input type="login" id='login' name="login" required>
                    <label>Login</label>
                </div>
                <div class="input-box">
                    <span class="icon"><ion-icon name="lock-closed-outline"></ion-icon></span>
                    <input type="password" name="password" id="password"required>
                    <label>Hasło</label>
                </div>
                <button type="sumbit" class="btn" id="loginFormBtn">Login</button>
                <?php 
                if(isset($_COOKIE['invalidLogin']) && $_COOKIE['invalidLogin']) {
                    echo'<p id="invalidLoginOrPassword">Podano niepoprawny login lub haslo</p>';
                }
                ?>
                <?php 
                if(isset($_COOKIE['invalidReg']) && $_COOKIE['invalidReg']) {
                    echo'<p id="invalidLoginOrPassword">Podany użytkownik już istnieje</p>';
                }
                ?>
                <div class="login-register">
                    <p>Nie masz jeszcze konta?<a href="#" class="register-link"><br>Register</a></p>
                </div>
            </form>
        </div>

        <div class="form-box register">
            <h2>Registration</h2>
            <form action="register.php" method="post">
                <div class="input-box">
                    <span class="icon"><ion-icon name="person-outline"></ion-icon>
                    </span>
                    <input type="text" id = "imie" name = "imie" required>
                    <label>Imie</label>
                </div>
                <div class="input-box">
                    <span class="icon"><ion-icon name="person-outline"></ion-icon>
                    </span>
                    <input type="text" id = "nazwisko" name = "nazwisko" required>
                    <label>Nazwisko</label>
                </div>
                <div class="input-box">
                    <span class="icon"><ion-icon name="person-outline"></ion-icon>
                    </span>
                    <input type="number" id = "telefon" name = "telefon" max="999999999" required>
                    <label>Numer Telefonu</label>
                </div>
                <div class="input-box">
                    <span class="icon"><ion-icon name="person-outline"></ion-icon>
                    </span>
                    <input type="text" id = "login" name = "login" required>
                    <label>Nazwa użytkownika</label>
                </div>
                <div class="input-box">
                    <span class="icon"><ion-icon name="mail-outline"></ion-icon></span>
                    <input type="email" id = "email" name = "email" required>
                    <label>Email</label>
                </div>
                <div class="input-box">
                    <span class="icon"><ion-icon name="lock-closed-outline"></ion-icon></span>
                    <input type="password" id = "password" name = "password" required>
                    <label>Hasło</label>
                </div>
                <div class="remember-forgot">
                    <label><input type="checkbox" required>Zapoznałem się z polityką prywatności.</label>
                </div>
                <button type="sumbit" class="btn" id = 'register'>Register</button>
                <div class="login-register">
                    <p>Czy masz już konto?<a href="#" class="login-link">Login</a></p>
                </div>
            </form>
        </div>
    </div>


    <script type="module" src="https://unpkg.com/ionicons@7.1.0/dist/ionicons/ionicons.esm.js"></script>
    <script nomodule src="https://unpkg.com/ionicons@7.1.0/dist/ionicons/ionicons.js"></script>


</body>
</html>