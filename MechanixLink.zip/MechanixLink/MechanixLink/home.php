<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Home - MechanixLink</title>
    <link rel="stylesheet" href="style.css">
</head>

<body>
    <header>
        <h2 class="logo">MechanixLink</h2>
        <nav class="navigation">
            <a href="home.php">Home</a>
            <a href="about.php">O nas</a>
            <a href="contact.php">Kontakt</a>
            <a href="privacy.php">Polityka prywatności</a>
            <button class="btnLogin-popup" id="loginBtn">Login</button>
        </nav>
    </header>

    <section class="home-section">
        <div class="home-container">
            <h1>Strona Domowa - MechanixLink</h1>
            <p>
                Jesteśmy specjalistycznym warsztatem samochodowym oferującym szeroką gamę usług naprawczych.
                Nasza ekipa doświadczonych mechaników zadba o Twoje auto, zapewniając szybkie i profesjonalne naprawy.
            </p>
            
            <div id="service-details">
                <h2>Nasze Usługi</h2>
                <ul>
                    <li>Naprawy mechaniczne</li>
                    <li>Naprawy elektryczne</li>
                    <li>Diagnostyka komputerowa</li>
                    <li>Wymiana oleju i filtra</li>
                    <li>Regeneracja układu hamulcowego</li>
                    <li>Wulkanizacja i wymiana opon</li>
                </ul>
            </div>
        </div>
    </section>

    <script src="loginregister.js"></script>
    <script type="module" src="https://unpkg.com/ionicons@7.1.0/dist/ionicons/ionicons.esm.js"></script>
    <script nomodule src="https://unpkg.com/ionicons@7.1.0/dist/ionicons/ionicons.js"></script>

</body>

</html>
