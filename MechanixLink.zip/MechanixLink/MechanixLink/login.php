<?php 
$conn = new mysqli('localhost:3306','guest','Nl5m8hCVkrE)nx/G','mechanix');

if($_SERVER['REQUEST_METHOD'] === 'POST') {
    $login = $_POST['login'];
    $password = $_POST['password'];

    // Zabezpieczenie przed SQL injection
    $login = mysqli_real_escape_string($conn, $login);
    $password = mysqli_real_escape_string($conn, $password);
    $sql = "SELECT * FROM uzytkownicy WHERE login = '$login' AND haslo = '$password' AND typ = 'klient'";
    $result = $conn->query($sql);
    if ($result->num_rows > 0) {
        $row = $result->fetch_row(); 
        session_start();
        $_SESSION['id'] = $row[0];
        session_commit();
        $conn->close();
        if(isset($_COOKIE['invalidLogin']) && $_COOKIE['invalidLogin']) {
            setcookie('invalidLogin',false,time() + 1,'/');
        }
        header('Location: panel.php');
    } else {
        // Nieprawidłowe dane logowania
        $conn->close();
        setcookie('invalidLogin',true,time() + 1,'/');
        header('Location: loginregister.php');
    }
}
?>
