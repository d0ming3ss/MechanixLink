<?php
session_start();
if(!isset($_SESSION['id'])) {
    session_abort();
    header('Location: loginregister.php');
}

class Status {
    public static function get_status() {
        $conn = new mysqli('localhost:3306','guest','Nl5m8hCVkrE)nx/G','mechanix');
        $conn -> begin_transaction();
        $id = $_SESSION['id'];
        $sql = "SELECT terminy.id, samochody.marka, samochody.model,uslugi.rodzaj_uslugi, warsztaty.adres ,terminy.status_zlecenia FROM terminy JOIN samochody ON samochody.id = terminy.id_samochodu JOIN klienci ON klienci.id_klienta = samochody.wlasciciel JOIN warsztaty ON warsztaty.id = terminy.id_warsztatu JOIN uslugi ON uslugi.id = terminy.id_uslugi WHERE samochody.wlasciciel = '$id' ORDER BY terminy.id DESC";
        $conn -> commit(); 
        $result = $conn -> query($sql);
        echo "<table border='1'>
                <tr>
                    <th>ID zlecenia</th>
                    <th>Marka</th>
                    <th>Model</th>
                    <th>Rodzja naprawy</th>
                    <th>Adres</th>
                    <th>Status</th>
                    <th>Wycofaj zlecenie</th>
                </tr>";
                while($row = $result -> fetch_assoc()) {
                    echo "<tr>";
                    echo "<td>" . $row['id'] . "</td>";
                    echo "<td>" . $row['marka'] . "</td>";
                    echo "<td>" . $row['model'] . "</td>";
                    echo "<td>" . $row['rodzaj_uslugi'] . "</td>";
                    echo "<td>" . $row['adres'] . "</td>";
                    echo "<td>" . $row['status_zlecenia'] . "</td>";
                    if($row["status_zlecenia"] != "zakonczony" && $row["status_zlecenia"] != 'w trakcie naprawy') { 
                        echo "<td><form action='deleteRequest.php' method='post'><button type = 'submit' id='delReq' name = 'id' value = '". $row['id'] ."'>X</button></form></td>";
                    } else echo "<td></td>";
                    echo "</tr>";
            }
    }
}

$status = new Status();
$status -> get_status();
session_commit();
?>