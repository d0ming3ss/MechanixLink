<?php
session_start();
if(!isset($_SESSION['id'])) {
    header('Location: loginregister.php');
}

class requestPrice {
    public function request() {
        $conn = new mysqli('localhost:3306','guest','Nl5m8hCVkrE)nx/G','mechanix');
        $conn -> begin_transaction();
        $sql = "SELECT rodzaj_uslugi, cena FROM `uslugi`";
        $conn -> commit(); 
        $result = $conn -> query($sql);
        echo "<table border='1'>
                <tr>
                    <th>Rodzaj uslugi</th>
                    <th>Cena</th>
                </tr>";
                while($row = $result -> fetch_assoc()) {
                    echo "<tr>";
                    echo "<td>" . $row['rodzaj_uslugi'] . "</td>";
                    echo "<td>" . $row['cena'] . "</td>";
                    echo "</tr>";
            }
    }
}

$request = new requestPrice();
$request -> request();
session_commit();
?>