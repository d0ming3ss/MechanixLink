<?php
session_start();
if(!isset($_SESSION['id'])) {
    session_abort();
    header('Location: loginregister.php');
}
$conn = new mysqli('localhost','admin','','mechanix');

$brand = $_POST['serviceTypeBrand'];
$carModel = $_POST['carModel'];
$engine = $_POST['engineType'];
$vin = $_POST['vinNumber'];
$service = $_POST['serviceType'];
$workshop = $_POST['selectWorkshop'];
$fuel = $_POST['fuelType'];
$idKlienta = $_SESSION['id'];


if($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        $conn -> begin_transaction();
        $sql = "INSERT INTO `samochody` (`id`, `marka`, `model`, `pojemnosc_silnika`, `rodzaj_paliwa`, `numer_vin`, `wlasciciel`) VALUES (NULL,'$brand', '$carModel', '$engine', '$fuel', '$vin', '$idKlienta')";
        $conn->query($sql);

        $result = $conn->query("SELECT id FROM samochody WHERE numer_vin='$vin'");
        $row = $result -> fetch_row();

        $sql = "INSERT INTO `terminy` (`id`, `id_warsztatu`,`id_uslugi`, `id_samochodu`, `status_zlecenia`, `data_przyjecia`, `data_oddania`) VALUES (NULL, '$workshop','$service', '$row[0]', 'przyjety', current_timestamp(), 'null')";
        $conn->query($sql);
        $conn->commit();
        session_commit();
        header('Location: panel.php');
    } catch (mysqli_sql_exception $e) {
        $conn->rollback();
    }
    
}
?>