<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Polityka Prywatności - MechanixLink</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <header>
        <h2 class="logo">MechanixLink</h2>
        <nav class="navigation">
            <a href="home.php">Home</a>
            <a href="about.php">O nas</a>
            <a href="contact.php">Kontakt</a>
            <a href="privacy.php">Polityka prywatności</a>
            <button class="btnLogin-popup" id="loginBtn">Login</button>
        </nav>
    </header>

    <section class="privacy-section">
        <div class="blurred-background">
            <div class="content-container">
                <h1>Polityka Prywatności</h1>
                <div class="scrollable-content">
                    <p>
                        Dziękujemy za odwiedzenie naszej strony internetowej. Dbamy o Twoją prywatność i pragniemy,
                        abyś poczuł się komfortowo korzystając z naszych usług. Poniżej przedstawiamy informacje na
                        temat tego, jak zbieramy, używamy i chronimy Twoje dane osobowe.
                    </p>
                    <p>
                        <strong>1. Rodzaje zbieranych danych</strong>
                        <br>
                        Informujemy, że zbieramy tylko niezbędne dane, takie jak imię, adres e-mail, itp. Wszystkie
                        dane są przechowywane zgodnie z obowiązującymi przepisami dotyczącymi ochrony danych.
                    </p>
                    <p>
                        <strong>2. Cel zbierania danych</strong>
                        <br>
                        Gromadzimy dane w celu świadczenia lepszych usług, dostosowanych do Twoich potrzeb.
                        Nie udostępniamy Twoich danych osobowych osobom trzecim bez Twojej zgody.
                    </p>
                    <p>
                        <strong>3. Ochrona danych</strong>
                        <br>
                        Stosujemy środki bezpieczeństwa, aby chronić Twoje dane przed nieuprawnionym dostępem
                        i utratą. Regularnie przeglądamy nasze procedury bezpieczeństwa, aby utrzymać najwyższy
                        poziom ochrony.
                    </p>
                    <p>
                        <strong>4. Udostępnianie danych osobowych</strong>
                        <br>
                        Nie udostępniamy Twoich danych osobowych stronom trzecim bez Twojej zgody, z wyjątkiem sytuacji wymaganych przepisami prawa.
                    </p>
                    <p>
                        <strong>5. Bezpieczeństwo danych</strong>
                        <br>
                        Podjęliśmy odpowiednie środki bezpieczeństwa, aby chronić Twoje dane osobowe przed nieautoryzowanym dostępem, utratą lub ujawnieniem.
                    </p>
                    <p>
                        <strong>6. Zmiany w polityce prywatności</strong>
                        <br>
                        Zachowujemy sobie prawo do wprowadzania zmian w naszej polityce prywatności. Wszelkie zmiany będą publikowane na tej stronie.
                    </p>
                    <p>
                        <strong>Jeśli masz pytania dotyczące naszej polityki prywatności, skontaktuj się z nami pod adresem: info@mechanixlink.com</strong>
                    </p>
                    <p>
                        <strong>Dziękujemy za zaufanie!</strong>
                    </p>
                </div>
            </div>
        </div>
    </section>

    <script src="loginregister.js"></script>
    <script type="module" src="https://unpkg.com/ionicons@7.1.0/dist/ionicons/ionicons.esm.js"></script>
    <script nomodule src="https://unpkg.com/ionicons@7.1.0/dist/ionicons/ionicons.js"></script>

</body>
</html>
