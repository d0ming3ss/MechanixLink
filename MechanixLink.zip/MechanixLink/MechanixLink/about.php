<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>O nas - MechanixLink</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <header>
        <h2 class="logo">MechanixLink</h2>
        <nav class="navigation">
            <a href="home.php">Home</a>
            <a href="about.php">O nas</a>
            <a href="contact.php">Kontakt</a>
            <a href="privacy.php">Polityka prywatności</a>
            <button class="btnLogin-popup" id="loginBtn">Login</button>
        </nav>
    </header>

    <section class="about-section">
        <div class="blurred-background">
            <div class="content-container">
                <h1>Witaj w warsztacie MechanixLink!</h1>
                <p>
                    Dziękujemy,za wybór naszej renomowanej sieci warsztatów mechanicznych. Z dumą informujemy, że jesteśmy dominującą siłą w świecie motoryzacyjnym we Wrocławiu. 
                    Nasza pasja do doskonałości oraz zaufanie naszych klientów uczyniły nas liderem branży. Oto kilka kluczowych informacji, które mogą zainteresować naszych klientów:
                </p>
                <p>
                    <strong>Ekspercka Obsługa Techniczna:</strong>
                    <br>
                    Nasi doświadczeni technicy i mechanicy posiadają nie tylko wiedzę, ale i pasję do świadczenia najwyższej jakości usług. To nasza zaleta, która przekłada się na bezpieczeństwo i zadowolenie klientów.
                </p>
                <p>
                    <strong>Innowacyjne Technologie:</strong>
                    <br>
                    W naszych warsztatach wykorzystujemy najnowocześniejsze technologie i sprzęt diagnostyczny, aby zapewnić precyzyjne i efektywne naprawy. To gwarancja, że każdy pojazd jest w najlepszych rękach.
                </p>
                <p>
                    <strong>Transparentność Kosztów:</strong>
                    <br>
                    Na naszej stronie internetowej znajdą Państwo klarowny cennik usług, co zapewnia pełną przejrzystość w kwestiach finansowych. Dzięki temu nasi klienci zawsze wiedzą, za co płacą.
                </p>
                <p>
                    <strong>Komunikacja Online:</strong>
                    <br>
                    Dla wygody naszych klientów udostępniamy możliwość śledzenia statusu naprawy online, a także umawiania terminów za pośrednictwem naszej strony internetowej. Chcemy, aby korzystanie z naszych usług było łatwe i dostosowane do współczesnych oczekiwań.
                </p> 
                <p>
                    <strong>Zaufanie Klientów:</strong>
                    <br>
                    Opinie naszych zadowolonych klientów są dla naszej sieci najważniejsze. Dbamy o budowanie pozytywnych relacji i zdobywanie zaufania poprzez profesjonalizm i skuteczność.
                </p>
                <p>
                    <strong>Programy Rabatowe:</strong>
                    <br>
                    Regularnie oferujemy atrakcyjne promocje i programy rabatowe, aby nagrodzić lojalność naszych klientów. To nasza forma podziękowania za zaufanie, jakim nas obdarzają.
                </p>
            </div>
        </div>
    </section>

    <script src="loginregister.js"></script>
    <script type="module" src="https://unpkg.com/ionicons@7.1.0/dist/ionicons/ionicons.esm.js"></script>
    <script nomodule src="https://unpkg.com/ionicons@7.1.0/dist/ionicons/ionicons.js"></script>

</body>
</html>