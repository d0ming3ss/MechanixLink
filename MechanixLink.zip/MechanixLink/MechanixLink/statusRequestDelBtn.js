document.addEventListener('DOMContentLoaded', () => {
const deleteBtn = document.querySelector('#delReq');

if(deleteBtn) {
    deleteBtn.addEventListener('click', () => {
        console.log('test');
    })
}
});